def price_calculator(frame, handle_bar_brakes, seating, wheels, chain_assembly):
    price = 0
    frame_materials = ['steel', 'aluminium']
    break_option = ['abs', 'non-abs']
    seating_option = ['single', 'double']
    tyre_option = ['tubeless', 'tube']
    if(frame == frame_materials[0]):
        price += 100
    elif(frame == frame_materials[1]):
        price += 150
    if(handle_bar_brakes == break_option[0]):
        price += 150
    elif(handle_bar_brakes == break_option[1]):
        price += 100
    if(seating == seating_option[0]):
        price += 100
    elif(seating == seating_option[1]):
        price += 200
    if(wheels == tyre_option[0]):
        price += 250
    elif(wheels == tyre_option[1]):
        price += 200
    return price
price = price_calculator(input('Enter the frame material: '), input('Enter the brake option: '), input('Enter the seating option: '), input('Enter the tyre option: '), input('Enter the gear option: '))
print(price)